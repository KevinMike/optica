(function($){$.fn.formset=function(opts) {
    var options=$.extend({},$.fn.formset.defaults,opts);var updateElementIndex=function(el,prefix,ndx){var id_regex=new RegExp('('+prefix+'-\\d+)');var replacement=prefix+'-'+ndx;if($(el).attr("for"))$(el).attr("for",$(el).attr("for").replace(id_regex,replacement));if(el.id)el.id=el.id.replace(id_regex,replacement);if(el.name)el.name=el.name.replace(id_regex,replacement);};$(this).each(function(i){$(this).addClass(options.formCssClass);if($(this).is('TR')){$(this).children(':last').append('<a class="' +options.deleteCssClass+'" href="javascript:void(0)">'+options.deleteText+'</a>');}else if($(this).is('UL')||$(this).is('OL')){$(this).append('<li><a class="'+options.deleteCssClass+'" href="javascript:void(0)">'+options.deleteText+'</a></li>');}else{$(this).children('div:last').children(1).append('<a class="col-sm-1 btn btn-danger  '+options.deleteCssClass+'" href="javascript:void(0)">'+options.deleteText+'</a>');}

$(this).find('a.'+options.deleteCssClass).click(function(){
    var row=$(this).parents('.'+options.formCssClass);row.remove();
    if(options.removed)options.removed(row);
    var forms=$('.'+options.formCssClass);
    $('#id_'+options.prefix+'-TOTAL_FORMS').val(forms.length);
    if(forms.length  < parseInt($('#id_'+options.prefix+'-MAX_NUM_FORMS').val())){
        $('a.'+options.addCssClass).show();
    }
    if(forms.length==1){$('a.'+options.deleteCssClass).hide();


    $('a.'+options.addCssClass).show();}


    for(var i=0,formCount=forms.length;i<formCount;i++){
        $(forms.get(i)).find('input,select,textarea,label').each(function(){
            updateElementIndex(this,options.prefix,i);
        });
    }
    return false;
});});
    if($(this).length ){
        var $addBtn;
        if($(this).attr('tagName')=='TR'){
            var numCols=this.eq(0).children().length;
            $(this).parent().append('<tr><td colspan="'+numCols+'"><a class="'+options.addCssClass+'" href="javascript:void(0)">'+options.addText+'</a></tr>');
            $addBtn=$(this).parent().find('tr:last a');
        }
        else{
            $(this).filter(':last').after('<a class="btn btn-success col-xs-10 col-sm-2 '+options.addCssClass+'" href="javascript:void(0)">'+options.addText+'</a>');
            $addBtn=$(this).filter(':last').next();}
$addBtn.click(function(){
    if(parseInt($('#id_'+options.prefix+'-TOTAL_FORMS').val() )< parseInt($('#id_'+options.prefix+'-MAX_NUM_FORMS').val())){

        var nextIndex=parseInt($('#id_'+options.prefix+'-TOTAL_FORMS').val());
        console.log(nextIndex);
        var row=$('.'+options.formCssClass+':first').clone(true).get(0);$(row).removeAttr('id').insertAfter($('.'+options.formCssClass+':last'));
        $(row).find('input,select,textarea,label').each(function(){
            updateElementIndex(this,options.prefix,nextIndex);
            var elem=$(this);
            if(elem.is('input:checkbox')||elem.is('input:radio')){elem.attr('checked',false);
            }
            else{
                elem.val('');
            }
        });
        var formCount=nextIndex+1;
        $('#id_'+options.prefix+'-TOTAL_FORMS').val(formCount);
        max_num = parseInt($('#id_'+options.prefix+'-MAX_NUM_FORMS').val())
        if(formCount== max_num){$('a.'+options.addCssClass).hide();
        }
        if(formCount>1){$('a.'+options.deleteCssClass).show();
        }
        if(options.added)options.added($(row));return false;
    }
});
}
if($(this).length==1){$('a.'+options.deleteCssClass).hide();}
return $(this);}
$.fn.formset.defaults={prefix:'formset',addText:'Añadir más',deleteText:'-',addCssClass:'add-row',deleteCssClass:'delete-row',formCssClass:'dynamic-form',added:null,removed:null}})(jQuery)
