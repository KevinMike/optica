/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v0.11.0-rc2-master-587cd22
 */
goog.provide("ng.material.components.whiteframe"),angular.module("material.components.whiteframe",[]),ng.material.components.whiteframe=angular.module("material.components.whiteframe");