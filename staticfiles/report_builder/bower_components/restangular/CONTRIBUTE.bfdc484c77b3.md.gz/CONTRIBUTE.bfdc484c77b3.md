In order to Contribute just git clone the repository and then run:

```
npm install grunt-cli --global
npm install
grunt
```

Be sure to have PhantomJS installed as Karma tests use it. Otherwise, in mac just run 

```
brew install phantomjs
```

All changes must be done in src/restangular.js and then after running grunt all changes will be submited to dist/

Please submit a Pull Request or create issues for anything you want :).
